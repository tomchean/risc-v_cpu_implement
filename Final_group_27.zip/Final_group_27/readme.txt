Besides CHIP.v, we seperate each module as a file, so there are multiple .v files. 
To synthesis, juse the same as TA's requirement, ie: ncveriliog Final_tb.v +define+xxx +access+r
